{
  "hash": "9eb962b5c39ec066d579b08af37e63bba8725276856a010232d9347e159c11ea",
  "signature": "AR8KEAABQR/nTl05ASusBX8vYyY1voDmB/PNfD/PMqB9UCGoVBvGBhQag5QrgeAX2Q7OU5HoNk5HNTy8ZE8RMxzY/teITK4W",
  "signer": "Verus Coin Foundation Releases@"
}
