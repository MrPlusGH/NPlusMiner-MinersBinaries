# Changelist #

### 1.2

* Stratum connection stability improved
* Bugfix: edge cases with lost shares
* Command line intensity `-i` and `--intensity` argument now works with X22i
* Algorithm name command argument now non-case sensitivity

### 1.0

* New coin supported: SUQA (X22i algorithm). Experimental SUQA branch merged into official branch
* Print hashrate per GPU enabled by default. Added new `--hide-hashrate-per-gpu` to disable it
* Total amount of shares sent to stratum added to the debug-info message
* `-T` and `--timeout` argument added to setup stratum connection timeout
* Added cuckoo CPU verification when a cycle is found
* Bugfix: Selecting a subset of gpus with `-d` and setting `--device-gpu-threads` per gpu didn't work as expected
* Timeout added when waiting response from stratum when a share is found, `--share-timeout` argument from the command line is available to setup it
* SUQA improvements compared to experimental branch:
  * Some speed improvements
  * Some CUDA error issues fixed

### 0.98

* Improved GPU errors checking
* Miner restarts automatically if GPUs are not working properly (0 cycles/s issue). This behavior can be disabled with `--disable-restart-on-gpu-error` If disabled, instead of auto-restarting itself it will quit.
* Improved stratum management
* New dump output to file feature. Use `-L` or `--log-file` followed by the name of the file

### 0.971

* EthMonitoring compatible: `--no-color` treated as a valid parameter (ignored by the miner). It makes zjazz compatible with EthMonitoring when using the miner as ccminer API
* API summary/gpus incorrect hashrate bugfix
* API added threads function, better ccminer compatibilily (gpus and threads API functions do the same)
* API: Connected message only printed if `--debug-info` is enabled

### 0.97

* Bitcash 3Gb GPUs support on Windows
* First API version: ccminer-like. summary, pool, gpus and quit functions available. `-b/--api-bind`
* List of failover pools added. Use multiple times `-o` (`--url`)
* GPU timeout feature added: Application quits if new blocks from stratum are received and GPUs are not mining. Timeout value can be set with `--gpu-timeout`
* Improved stats, show hashrate detailed per GPU with `--hashrate-per-gpu`
* -`-cuckoo-intensity` 18 bugfix
* Added some debug info messages. `--debug-info` to enable them
* User friendly GPU memory errors presentation
* Set the number of threads per device `--device-gpu-threads`
* Hashrate reliable % message added
* Per line ok/ko state message added
* Force GPU processing to stop when connection with stratum server is lost
* Time to wait before reconnecting configurable: `-R/--retry-pause` parameter added

### 0.96

* New coin supported: BitCash
* New cuckoo experimental feature `--cuckoo-intensity`
* Official Linux release (previously only available from the experimental repository)
* Improved stratum management
* Added extra error messages and minor fixes

### 0.95 ###

* 3Gb GPUS support: Cuckoo memory usage improved from 2.8Gb to 2.19Gb
* Cuda 9.1 dll included on Windows package: no more dll not found errors

### 0.93

* First release
* Cuckoo algorithm (MeritCoin)

